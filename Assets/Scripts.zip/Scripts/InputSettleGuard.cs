using UnityEngine;

/// <summary>
/// 画面が切り替わった直後の「キー連打・押しっぱなしの勢い」で、メニューの決定や会話送りが
/// 意図せず実行されるのを防ぐ小さなガード（値型・非確保）。
///
/// 使い方: 画面 / パネルが出たタイミング（OnEnable / 再生開始）で <see cref="Reset"/> を呼び、
/// 入力処理の前に <see cref="Ready"/>(対象入力が今どれか押されているか) が true のときだけ入力を通す。
///
/// 入力を受け付け始める条件: Reset 以降、対象入力が **settleSeconds 秒（unscaled）連続で「どれも
/// 押されていない」** 状態になること。対象入力が押されている間は計測が進まない（＝時刻が更新され続ける）ので、
/// 連打していると release フレームがあってもガードは解けず、「連打・押しっぱなしをやめて一拍おく」まで
/// 入力が通らない。一度解けたら次の Reset までずっと通る。
///
/// 単純な時間ロック（＋一度離す）だと、連打には release フレームがあるためロック明けに1発通ってしまう。
/// 「連続で静か」を条件にすることで、連打している限り絶対に通らない。
/// </summary>
public struct InputSettleGuard
{
    private float _quietSinceUnscaled;
    private float _settle;
    private bool _armed;

    public void Reset(float settleSeconds)
    {
        _settle = Mathf.Max(0f, settleSeconds);
        _quietSinceUnscaled = Time.unscaledTime;
        _armed = false;
    }

    /// <summary>入力を通してよいか。anyInputHeld = ガード対象の入力が今どれか押されているか。</summary>
    public bool Ready(bool anyInputHeld)
    {
        if (_armed) return true;

        if (anyInputHeld)
        {
            _quietSinceUnscaled = Time.unscaledTime; // 静かになった時刻を今に更新 → 解除を先送り
            return false;
        }

        if (Time.unscaledTime - _quietSinceUnscaled >= _settle)
        {
            _armed = true;
            return true;
        }
        return false;
    }
}
